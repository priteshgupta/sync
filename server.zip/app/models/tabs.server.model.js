'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * Tabs Schema
 */
var TabsSchema = new Schema({
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  },
  tabs: {},
});

mongoose.model('Tabs', TabsSchema);
