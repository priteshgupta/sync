'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

/**
 * History Schema
 */
var HistorySchema = new Schema({
  user: {
    type: Schema.ObjectId,
    ref: 'User'
  },
  chrome: {},
  firefox: {},
});

mongoose.model('History', HistorySchema);
