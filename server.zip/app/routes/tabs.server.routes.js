'use strict';

/**
 * Module dependencies.
 */
var users = require('../../app/controllers/users.server.controller'),
  tabs = require('../../app/controllers/tabs.server.controller');

module.exports = function(app) {
  // Tabs Routes
  app.route('/tabs/:userId')
    .get(tabs.listById)
    .post(tabs.createById);

  app.route('/tabs')
    .get(tabs.list)
    .post(users.requiresLogin, tabs.create);

  // Finish by binding the tab middleware
  // app.param('tabId', tabs.tabByID);
};
