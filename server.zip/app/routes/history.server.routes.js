'use strict';

/**
 * Module dependencies.
 */
var users = require('../../app/controllers/users.server.controller'),
  historyC = require('../../app/controllers/history.server.controller');

module.exports = function(app) {
  // Tabs Routes
  app.route('/history/:userId')
    .get(historyC.listById);

  app.route('/history/:userId/:browser')
    .post(historyC.updateHistory);

  app.route('/create-history/:userId')
    .get(historyC.createById);

  // app.route('/historyC')
  //   .get(historyC.list)
  //   .post(users.requiresLogin, historyC.create);

  // Finish by binding the tab middleware
  // app.param('tabId', historyC.tabByID);
};
