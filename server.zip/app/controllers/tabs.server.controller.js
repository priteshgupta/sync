'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  errorHandler = require('./errors.server.controller'),
  Tabs = mongoose.model('Tabs'),
  _ = require('lodash');

/**
 * Create a tabs
 */
exports.create = function(req, res) {
  var tabs = new Tabs(req.body);
  tabs.user = req.user;

  Tabs.find({user: req.user.id}).remove().exec();

  tabs.save(function(err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(tabs);
    }
  });
};

exports.createById = function(req, res) {
  var tabs = new Tabs(req.body);
  tabs.user = req.params.userId;

  Tabs.find({user: req.params.userId}).remove().exec();

  tabs.save(function(err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(tabs);
    }
  });
};

exports.listById = function(req, res) {
  Tabs.find({user: req.params.userId}).sort('-created').exec(function(err, tabss) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(tabss);
    }
  });
};

/**
 * List of Tabss
 */
exports.list = function(req, res) {
  Tabs.find({user: req.user.id}).sort('-created').exec(function(err, tabss) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(tabss);
    }
  });
};

/**
 * Tabs authorization middleware
 */
exports.hasAuthorization = function(req, res, next) {
  if (req.tabs.user.id !== req.user.id) {
    return res.status(403).send({
      message: 'User is not authorized'
    });
  }
  next();
};
