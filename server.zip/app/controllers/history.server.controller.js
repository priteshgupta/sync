'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
  errorHandler = require('./errors.server.controller'),
  History = mongoose.model('History'),
  _ = require('lodash');

/**
 * Create a history
 */
exports.createById = function(req, res) {
  var history = new History({
    chrome: {},
    firefox: {}
  });
  history.user = req.params.userId;

  history.save(function(err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(history);
    }
  });
};

exports.updateHistory = function(req, res) {
  var setValue = {};

  console.log(req.body);

  setValue[req.params.browser + '.' + req.body.time] = {
    url: req.body.url,
    title: req.body.title
  };

  History.update({user: req.params.userId}, {
    $set: setValue
  }).exec(function(err, numberAffected, raw) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(numberAffected);
    }
  });
};

exports.listById = function(req, res) {
  History.find({user: req.params.userId}).exec(function(err, history) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      if (!history[0] || (!history[0].chrome && !history[0].firefox)) {
        res.json({});
      }
      else if (history[0].chrome && !history[0].firefox) {
        res.json(history[0].chrome);
      }
      else if (!history[0].chrome && history[0].firefox) {
        res.json(history[0].firefox);
      }
      else {
        res.json(_.merge(history[0].chrome, history[0].firefox));
      }
    }
  });
};

/**
 * List of History
 */
exports.list = function(req, res) {
  History.find({user: req.user.id}).sort('-created').exec(function(err, history) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(history);
    }
  });
};

/**
 * History authorization middleware
 */
exports.hasAuthorization = function(req, res, next) {
  if (req.history.user.id !== req.user.id) {
    return res.status(403).send({
      message: 'User is not authorized'
    });
  }
  next();
};
